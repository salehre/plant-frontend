<script setup lang="ts">
import MobileBottomNav from '~/components/layout/MobileBottomNav.vue'
import TheFooter from '~/components/layout/TheFooter.vue'
import TheHeader from '~/components/layout/TheHeader.vue'
import TheSidebar from '~/components/layout/TheSidebar.vue'
</script>

<template>
  <div class="min-h-screen bg-bg">
    <TheSidebar />

    <!-- md:ps-64 = عرض سایدبار (در RTL سایدبار سمت راسته و در LTR سمت چپ) -->
    <div class="flex min-h-screen min-w-0 flex-col overflow-x-clip md:ps-64">
      <TheHeader />
      <main class="mx-auto w-full max-w-6xl flex-1 px-4 pt-4 sm:px-6">
        <slot />
      </main>

      <!-- فوتر سبز تیره: تمام عرض ستون محتوا (بدون سایدبار) -->
      <TheFooter class="mt-12" />
    </div>

    <MobileBottomNav />
  </div>
</template>
