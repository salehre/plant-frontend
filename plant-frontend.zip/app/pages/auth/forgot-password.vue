<script setup lang="ts">
import { toTypedSchema } from '@vee-validate/zod'
import { useForm } from 'vee-validate'
import { z } from 'zod'

definePageMeta({ layout: 'auth' })

const authStore = useAuthStore()
const uiStore = useUiStore()
const { t } = useI18n()

// این صفحه خودش سه قدمه (بدون رفتن به صفحه‌ی جدا): ایمیل → کد → رمز جدید.
// کد جداگانه وریفای نمی‌شه؛ همراه رمز جدید توی resetPassword با هم چک می‌شن -
// اگه کد غلط بود، برمی‌گردیم قدم کد (نه این‌که این‌جا خطا بدیم).
const step = ref<'email' | 'otp' | 'password'>('email')
const submittedEmail = ref('')

// ─── قدم ۱: ایمیل ───
const emailSchema = toTypedSchema(z.object({
  email: z.string().min(1, 'auth.emailRequired').email('auth.emailInvalid'),
}))
const { handleSubmit: handleEmailSubmit, defineField: defineEmailField, errors: emailErrors } = useForm({ validationSchema: emailSchema })
const [email, emailAttrs] = defineEmailField('email')

const onEmailSubmit = handleEmailSubmit(async (values) => {
  const code = await authStore.forgotPassword(values.email)
  if (code) {
    submittedEmail.value = values.email
    step.value = 'otp'
    startCountdown()
    // dev-only: چون ایمیل واقعی وصل نیست، کد رو همین‌جا نشون می‌دیم - Phase 3 حذف می‌شه.
    uiStore.showToast(t('auth.resetCodeSentDev', { code }))
  }
})

// ─── قدم ۲: کد (۶ خونه‌ی جدا) ───
const digits = ref<string[]>(['', '', '', '', '', ''])
const digitRefs = ref<HTMLInputElement[]>([])
const isCodeComplete = computed(() => digits.value.every(d => d !== ''))

function onDigitInput(index: number, event: Event) {
  const val = (event.target as HTMLInputElement).value.replace(/\D/g, '')
  digits.value[index] = val.slice(-1)
  authStore.error = ''
  if (val && index < 5) digitRefs.value[index + 1]?.focus()
}
function onKeyDown(index: number, event: KeyboardEvent) {
  if (event.key === 'Backspace' && !digits.value[index] && index > 0) {
    digitRefs.value[index - 1]?.focus()
  }
}
function onPaste(event: ClipboardEvent) {
  event.preventDefault()
  const pasted = event.clipboardData?.getData('text').replace(/\D/g, '').slice(0, 6) || ''
  pasted.split('').forEach((char, i) => { if (i < 6) digits.value[i] = char })
  digitRefs.value[Math.min(pasted.length, 5)]?.focus()
}

// کد این‌جا فقط لوکال چک می‌شه که خالی نباشه؛ اعتبار واقعیش رو resetPassword می‌سنجه.
function continueToPassword() {
  if (!isCodeComplete.value) return
  step.value = 'password'
}

const RESEND_SECONDS = 120
const countdown = ref(RESEND_SECONDS)
const resending = ref(false)
let timer: ReturnType<typeof setInterval> | null = null
const formatCountdown = computed(() => {
  const m = Math.floor(countdown.value / 60)
  const s = countdown.value % 60
  return `${m}:${s.toString().padStart(2, '0')}`
})
function startCountdown() {
  if (timer) clearInterval(timer)
  countdown.value = RESEND_SECONDS
  timer = setInterval(() => {
    if (countdown.value <= 0) clearInterval(timer!)
    else countdown.value--
  }, 1000)
}
onUnmounted(() => { if (timer) clearInterval(timer) })

async function resendCode() {
  resending.value = true
  try {
    const code = await authStore.sendOtp(submittedEmail.value, 'reset')
    uiStore.showToast(t('auth.newCodeSentDev', { code }), 'info')
    startCountdown()
    digits.value = ['', '', '', '', '', '']
    authStore.error = ''
  }
  finally {
    resending.value = false
  }
}

// ─── قدم ۳: رمز جدید ───
const passwordSchema = toTypedSchema(
  z.object({
    password: z.string().min(8, 'auth.passwordMin8'),
    passwordConfirm: z.string(),
  }).refine(data => data.password === data.passwordConfirm, {
    message: 'auth.passwordMismatch',
    path: ['passwordConfirm'],
  }),
)
const { handleSubmit: handlePasswordSubmit, defineField: definePasswordField, errors: passwordErrors } = useForm({ validationSchema: passwordSchema })
const [password, passwordAttrs] = definePasswordField('password')
const [passwordConfirm, passwordConfirmAttrs] = definePasswordField('passwordConfirm')
const showPassword = ref(false)
const showPasswordConfirm = ref(false)

const onPasswordSubmit = handlePasswordSubmit(async (values) => {
  const ok = await authStore.resetPassword(submittedEmail.value, digits.value.join(''), values.password)
  if (ok) {
    uiStore.showToast(t('auth.passwordChanged') + ' 🌿')
    navigateTo({ path: '/auth/login', query: { reset: 'true' } })
  }
  else {
    // کد اشتباه/منقضیه؛ برگرد قدم کد
    step.value = 'otp'
    digits.value = ['', '', '', '', '', '']
    setTimeout(() => digitRefs.value[0]?.focus(), 50)
  }
})

const stepNumber = computed(() => ({ email: 1, otp: 2, password: 3 }[step.value]))
</script>

<template>
  <div>
    <div class="mb-6 flex gap-2">
      <div
        v-for="s in 3"
        :key="s"
        class="h-1.5 flex-1 rounded-full transition-colors duration-300"
        :class="s <= stepNumber ? 'bg-accent-300' : 'bg-white/15'"
      />
    </div>

    <template v-if="step === 'email'">
      <h1 class="mb-1 text-xl font-bold text-white [text-shadow:0_1px_6px_rgba(0,0,0,0.3)]">
        {{ t('auth.resetTitle') }}
      </h1>
      <p class="mb-6 text-sm text-white/70">
        {{ t('auth.resetEmailSubtitle') }}
      </p>

      <form
        class="flex flex-col gap-4"
        novalidate
        @submit="onEmailSubmit"
      >
        <div>
          <label class="glass-label">{{ t('auth.email') }}</label>
          <input
            v-model="email"
            v-bind="emailAttrs"
            type="email"
            class="glass-input"
            :class="{ 'glass-input--error': emailErrors.email }"
            placeholder="you@example.com"
          >
          <p
            v-if="emailErrors.email"
            class="mt-1 text-xs text-red-200"
          >
            {{ emailErrors.email ? t(emailErrors.email) : '' }}
          </p>
        </div>

        <p
          v-if="authStore.error"
          class="rounded-lg border border-red-300/30 bg-red-500/15 p-2 text-sm text-red-100"
        >
          {{ t(authStore.error) }}
        </p>

        <AppButton
          type="submit"
          variant="accent"
          block
          :loading="authStore.loading"
        >
          {{ t('auth.sendResetCode') }}
        </AppButton>
      </form>
    </template>

    <template v-else-if="step === 'otp'">
      <h1 class="mb-1 text-xl font-bold text-white [text-shadow:0_1px_6px_rgba(0,0,0,0.3)]">
        {{ t('auth.verifyEmail') }}
      </h1>
      <p class="mb-6 text-sm text-white/70">
        {{ t('auth.enterCodeSentTo') }} <span class="font-medium text-white">{{ submittedEmail }}</span>.
      </p>

      <div class="flex flex-col gap-5">
        <div
          class="flex justify-center gap-2"
          dir="ltr"
        >
          <input
            v-for="(_, i) in 6"
            :key="i"
            :ref="el => (digitRefs[i] = el as HTMLInputElement)"
            v-model="digits[i]"
            type="text"
            inputmode="numeric"
            maxlength="1"
            autocomplete="one-time-code"
            class="h-12 w-11 rounded-xl border-2 border-white/20 bg-white/10 text-center text-xl font-bold text-white outline-none backdrop-blur-sm transition-colors duration-150 focus-visible:border-accent-300/70 focus-visible:bg-white/15"
            :class="{ 'border-red-300/60 bg-red-500/10': authStore.error, 'border-accent-300/70': digits[i] && !authStore.error }"
            @input="onDigitInput(i, $event)"
            @keydown="onKeyDown(i, $event)"
            @paste="onPaste"
            @focus="($event.target as HTMLInputElement).select()"
          >
        </div>

        <p
          v-if="authStore.error"
          class="rounded-lg border border-red-300/30 bg-red-500/15 p-2 text-center text-sm text-red-100"
        >
          {{ t(authStore.error) }}
        </p>

        <AppButton
          type="button"
          variant="accent"
          block
          :disabled="!isCodeComplete"
          @click="continueToPassword"
        >
          {{ t('auth.verifyCode') }}
        </AppButton>

        <p class="text-center text-sm text-white/70">
          <span v-if="countdown > 0">
            {{ t('auth.resendIn') }}
            <span class="font-bold tabular-nums text-accent-200">{{ formatCountdown }}</span>
          </span>
          <button
            v-else
            type="button"
            class="font-medium text-accent-200 hover:text-accent-100 disabled:opacity-60"
            :disabled="resending"
            @click="resendCode"
          >
            {{ t('auth.resendCode') }}
          </button>
        </p>
      </div>
    </template>

    <template v-else>
      <h1 class="mb-1 text-xl font-bold text-white [text-shadow:0_1px_6px_rgba(0,0,0,0.3)]">
        {{ t('auth.newPassword') }}
      </h1>
      <p class="mb-6 text-sm text-white/70">
        {{ t('auth.newPasswordSubtitle') }}
      </p>

      <form
        class="flex flex-col gap-4"
        novalidate
        @submit="onPasswordSubmit"
      >
        <div>
          <label class="glass-label">{{ t('auth.newPassword') }}</label>
          <div class="relative">
            <input
              v-model="password"
              v-bind="passwordAttrs"
              :type="showPassword ? 'text' : 'password'"
              class="glass-input pe-10"
              :class="{ 'glass-input--error': passwordErrors.password }"
              placeholder="••••••••"
            >
            <button
              type="button"
              class="absolute inset-y-0 end-0 flex w-10 items-center justify-center text-white/60 hover:text-white"
              :aria-label="showPassword ? t('auth.hidePassword') : t('auth.showPassword')"
              @click="showPassword = !showPassword"
            >
              <Icon
                :name="showPassword ? 'lucide:eye-off' : 'lucide:eye'"
                class="size-4"
              />
            </button>
          </div>
          <p
            v-if="passwordErrors.password"
            class="mt-1 text-xs text-red-200"
          >
            {{ passwordErrors.password ? t(passwordErrors.password) : '' }}
          </p>
        </div>

        <div>
          <label class="glass-label">{{ t('auth.confirmPassword') }}</label>
          <div class="relative">
            <input
              v-model="passwordConfirm"
              v-bind="passwordConfirmAttrs"
              :type="showPasswordConfirm ? 'text' : 'password'"
              class="glass-input pe-10"
              :class="{ 'glass-input--error': passwordErrors.passwordConfirm }"
              placeholder="••••••••"
            >
            <button
              type="button"
              class="absolute inset-y-0 end-0 flex w-10 items-center justify-center text-white/60 hover:text-white"
              :aria-label="showPasswordConfirm ? t('auth.hidePassword') : t('auth.showPassword')"
              @click="showPasswordConfirm = !showPasswordConfirm"
            >
              <Icon
                :name="showPasswordConfirm ? 'lucide:eye-off' : 'lucide:eye'"
                class="size-4"
              />
            </button>
          </div>
          <p
            v-if="passwordErrors.passwordConfirm"
            class="mt-1 text-xs text-red-200"
          >
            {{ passwordErrors.passwordConfirm ? t(passwordErrors.passwordConfirm) : '' }}
          </p>
        </div>

        <AppButton
          type="submit"
          variant="accent"
          block
          :loading="authStore.loading"
        >
          {{ t('auth.saveNewPassword') }}
        </AppButton>
      </form>
    </template>

    <p class="mt-5 text-center text-sm text-white/70">
      {{ t('auth.rememberPassword') }}
      <NuxtLink
        to="/auth/login"
        class="font-medium text-accent-200 hover:text-accent-100"
      >
        {{ t('auth.login') }}
      </NuxtLink>
    </p>
  </div>
</template>
